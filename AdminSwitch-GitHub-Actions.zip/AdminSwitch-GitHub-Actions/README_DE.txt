ADMINSWITCH – GITHUB-ACTIONS-PROJEKT
===================================

Ziel:
- Server-Mod: setzt exakt Dr_Lunsta beim Beitritt auf Creative.
- Client-Mod: Pfeil-rechts sendet den normalen Befehl /gamemode survival.
- Beide JARs werden von GitHub Actions gebaut und als ein Artifact bereitgestellt.

WICHTIGE EINSCHRÄNKUNG:
Dieses Projekt ist ein vorbereiteter Build-Entwurf, kein erfolgreich getesteter Release.
Die Minecraft-26.3/Fabric-Client-API kann sich ändern. Erst wenn GitHub Actions gruen
durchlaeuft und beide JARs im Artifact liegen, ist der Build bestaetigt.
Der Survival-Befehl benoetigt auf dem Server die normalen Rechte des Spielers.
Der Server-Mod gibt keine Operator-Rechte und keine zusaetzlichen Rechte.

SO NUTZT DU ES:
1. Auf GitHub ein neues leeres Repository erstellen, z.B. AdminSwitch.
2. Den Inhalt dieses ZIP-Ordners in das Repository hochladen (nicht den ZIP-Ordner
   als verschachtelten Unterordner).
3. Im Repository auf Actions gehen.
4. "Build AdminSwitch JARs" auswaehlen und "Run workflow" starten.
5. Nach erfolgreichem Lauf den Lauf oeffnen und unter Artifacts "AdminSwitch-JARs"
   herunterladen.
6. Im Artifact liegen:
   - AdminSwitch-Server-1.0.0.jar -> in den Server-mods-Ordner
   - AdminSwitch-Client-1.0.0.jar -> in den Client-mods-Ordner

Beide Seiten muessen Minecraft 26.3 und Fabric verwenden.
Falls der Build fehlschlaegt: den roten Fehlertext aus Actions kopieren und schicken.
Keine JAR installieren, solange der Build rot ist oder die Dateien fehlen.
