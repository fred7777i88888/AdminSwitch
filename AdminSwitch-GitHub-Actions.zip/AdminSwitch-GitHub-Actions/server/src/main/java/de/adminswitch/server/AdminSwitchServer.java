package de.adminswitch.server;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.world.level.GameType;

public final class AdminSwitchServer implements ModInitializer {
    private static final String ADMIN_NAME = "Dr_Lunsta";

    @Override
    public void onInitialize() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            var player = handler.player;
            if (ADMIN_NAME.equals(player.getGameProfile().getName())) {
                player.setGameMode(GameType.CREATIVE);
            }
        });
    }
}
