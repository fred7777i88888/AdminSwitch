package de.adminswitch.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping.Category;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

public final class AdminSwitchClient implements ClientModInitializer {
    private static final KeyMapping SWITCH_TO_SURVIVAL = new KeyMapping(
        "key.adminswitch.survival",
        GLFW.GLFW_KEY_RIGHT,
        Category.MISC
    );

    @Override
    public void onInitializeClient() {
        KeyMapping.register(SWITCH_TO_SURVIVAL);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (SWITCH_TO_SURVIVAL.consumeClick()) {
                if (client.player != null && client.getConnection() != null) {
                    // The server still checks normal command permissions.
                    client.player.connection.sendCommand("gamemode survival");
                }
            }
        });
    }
}
